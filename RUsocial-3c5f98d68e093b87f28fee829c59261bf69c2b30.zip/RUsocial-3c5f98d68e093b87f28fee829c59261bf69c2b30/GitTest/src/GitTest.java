/**
 * Created by DMan on 2/28/2017.
 */
public class GitTest {

    public static void main(String[] args){

        char[] pack = {'R','A','D','P', 'A','C','K'};

        System.out.println("This is a Test");

        int check = 10;
        do{
            System.out.println(check);
            check--;
        }while(check != 0);

        System.out.println("We are the..");

        for(int pos = 0; pos < pack.length; pos++){
            System.out.println(pack[pos]);
        }

    }
}
